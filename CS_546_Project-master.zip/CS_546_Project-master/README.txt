TRIP PLANNER 
--------------------------
A. How to Run

1. Install Studio 3T
2. npm install
3. npm start
4. Go to URL - http://localhost:3000/          [This will automicatically create the database with DB name "Trip_Planner"]
5. Now, Import collection to the database by right click on the name of database
6. As you are a new user, you will need to Sign Up first.



